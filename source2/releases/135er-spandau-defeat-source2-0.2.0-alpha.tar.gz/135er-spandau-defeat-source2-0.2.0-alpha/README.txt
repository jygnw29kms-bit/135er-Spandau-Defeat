135er – Spandau Defeat 0.2.0-source2-alpha
CS2 / Source 2 server-side alpha package.
Contains only project-owned source/config/metadata and the CounterStrikeSharp plugin.
Does NOT contain Counter-Strike 2 or Valve engine binaries.
