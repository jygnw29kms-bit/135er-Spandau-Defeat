135er – Spandau Defeat 0.2.0-source2-alpha
CS2 / Source 2 alpha package.
Includes bot-navigation requirements and 17 map production specs.
No Valve engine binaries included.
