# 135er – Spandau Defeat 0.4.0 Native Unreal / History expansion

This is the native Unreal Engine 5.8 C++ migration of 135er – Spandau Defeat. It replaces the browser-client direction with a real desktop FPS client and a headless dedicated-server target.

## Implemented in source
- native Unreal Game target for Windows/Linux/macOS packaging
- native Unreal Server target for headless dedicated server builds
- server-authoritative CharacterMovement replication
- server-authoritative hitscan firing, rate limit, range and collision trace
- health, death, kills/deaths and 5-second respawn
- automatic team balancing (Allies / Axis working names)
- three network-replicated capture zones per battlefield
- nine core Spandau battlefield profiles, each nominally 1 km x 1 km
- eight historical/special map profiles spanning WWII, 1945 occupation, Berlin Airlift and Cold War
- runtime 3D graybox generation with real blocking collision and distinct urban/open/industrial layouts
- mouse/keyboard FPS controls
- Linux server launcher and 60 Hz network configuration

## Core map IDs
rathaus_spandau, zitadelle, staaken, rodelberg, kiesteich, falkenhagener_feld, lynarstrasse, wroehmaennerpark, freiheit

## Historical/special map IDs
fort_hahneberg_1945, teufelsberg_coldwar, flugplatz_gatow_1945, gatow_luftbruecke_1948, radeland_1945, hakenfelde_heeresamt_1944, zitadelle_1945, britischer_sektor_spandau

See `Docs/HISTORY_MAPS.md` for the historical-authenticity rules and per-map treatment.

## Build requirement
A licensed Unreal Engine 5.8 installation/source build is required. Dedicated Server targets require the Unreal source-build workflow documented by Epic.

Generate IDE files, compile `SpandauDefeat` for the desired desktop platform and `SpandauDefeatServer` for Linux. For a local server launch, pass `?MapId=zitadelle` or use `-SpandauMap=zitadelle`.

Example server URL:
`/Engine/Maps/Entry?game=/Script/SpandauDefeat.SDGameMode?MapId=zitadelle -server -log -port=27135`

Example client join from UE console:
`open 127.0.0.1:27135`

## What 0.4.0 is
This is a native multiplayer FPS graybox/vertical-slice codebase. It is not claiming that nine photoreal final Spandau maps, character art, weapon art, audio or animations are finished. Those require authored assets and cooked Unreal content. The gameplay path is native Unreal, not HTML/Canvas/WebSocket gameplay.
