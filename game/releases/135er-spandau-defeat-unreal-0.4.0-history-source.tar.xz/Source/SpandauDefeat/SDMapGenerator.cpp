#include "SDMapGenerator.h"
#include "Engine/StaticMeshActor.h"
#include "UObject/ConstructorHelpers.h"
#include "SDCaptureZone.h"
#include "Net/UnrealNetwork.h"
ASDMapGenerator::ASDMapGenerator(){bReplicates=true;bAlwaysRelevant=true;SetReplicateMovement(false);}
void ASDMapGenerator::Box(const FVector& L,const FVector& S,const FRotator& R)
{
    AStaticMeshActor* A=GetWorld()->SpawnActor<AStaticMeshActor>(L,R); if(!A)return;
    UStaticMesh* M=LoadObject<UStaticMesh>(nullptr,TEXT("/Engine/BasicShapes/Cube.Cube")); A->GetStaticMeshComponent()->SetStaticMesh(M); A->SetActorScale3D(S/100.f); A->GetStaticMeshComponent()->SetMobility(EComponentMobility::Static); A->GetStaticMeshComponent()->SetCollisionProfileName(TEXT("BlockAll"));
}
void ASDMapGenerator::BuildUrban(const FSDMapProfile& P,int32 Seed,float D)
{
    FRandomStream R(Seed); const float H=P.PlayAreaMeters*50.f; Box(FVector(0,0,-50),FVector(H*2,H*2,100));
    for(int32 i=0;i<int32(85*D);++i){float X=R.FRandRange(-H+4000,H-4000),Y=R.FRandRange(-H+4000,H-4000); if(FMath::Abs(X)<3500||FMath::Abs(Y)<3500)continue; float W=R.FRandRange(1800,5200),L=R.FRandRange(1800,6500),Z=R.FRandRange(1200,6500); Box(FVector(X,Y,Z*.5f),FVector(W,L,Z),FRotator(0,R.RandRange(0,3)*90.f,0));}
    for(int32 i=-5;i<=5;i++) Box(FVector(i*8000,0,80),FVector(2500,800,160));
}
void ASDMapGenerator::BuildOpen(const FSDMapProfile& P,int32 Seed,float D)
{
    FRandomStream R(Seed); const float H=P.PlayAreaMeters*50.f; Box(FVector(0,0,-50),FVector(H*2,H*2,100));
    for(int32 i=0;i<int32(42*D);++i){float X=R.FRandRange(-H,H),Y=R.FRandRange(-H,H); float W=R.FRandRange(800,2800),L=R.FRandRange(800,4000),Z=R.FRandRange(400,1800); Box(FVector(X,Y,Z*.5f),FVector(W,L,Z),FRotator(0,R.FRandRange(0,180),0));}
    for(int32 i=0;i<10;i++){ float X=R.FRandRange(-H,H),Y=R.FRandRange(-H,H); Box(FVector(X,Y,350),FVector(1000,1000,700)); }
}
void ASDMapGenerator::BuildIndustrial(const FSDMapProfile& P,int32 Seed)
{
    BuildUrban(P,Seed,0.65f); FRandomStream R(Seed+17); for(int i=0;i<24;i++){float X=R.FRandRange(-42000,42000),Y=R.FRandRange(-42000,42000);Box(FVector(X,Y,450),FVector(1200,600,900));}
}
static void AirfieldBoxes(ASDMapGenerator* G,const FSDMapProfile& P,int32 Seed)
{
    const float H=P.PlayAreaMeters*50.f; G->Box(FVector(0,0,-50),FVector(H*2,H*2,100));
    // runway + apron/hangars: deterministic gameplay blockout for historical art replacement
    G->Box(FVector(0,0,15),FVector(82000,4200,30));
    for(int i=-3;i<=3;i++) G->Box(FVector(i*11000,17000,1600),FVector(7000,4500,3200));
    for(int i=-2;i<=2;i++) G->Box(FVector(i*15000,-19000,900),FVector(5000,3200,1800));
}
static void FortressBoxes(ASDMapGenerator* G,const FSDMapProfile& P,int32 Seed)
{
    const float H=P.PlayAreaMeters*50.f; G->Box(FVector(0,0,-50),FVector(H*2,H*2,100));
    for(int i=0;i<4;i++){const float Y=(i<2?-1.f:1.f)*18500;const float X=(i%2?-1.f:1.f)*18500;G->Box(FVector(X,Y,1900),FVector(26000,2800,3800),FRotator(0,(i%2)*90.f,0));}
    G->Box(FVector(0,0,850),FVector(9000,7000,1700));
    for(int i=-4;i<=4;i++) G->Box(FVector(i*6000,-28500,450),FVector(2600,1200,900));
}
static void BarracksBoxes(ASDMapGenerator* G,const FSDMapProfile& P,int32 Seed)
{
    const float H=P.PlayAreaMeters*50.f; G->Box(FVector(0,0,-50),FVector(H*2,H*2,100));
    for(int r=-2;r<=2;r++) for(int c=-3;c<=3;c++) if((r+c)%2==0) G->Box(FVector(c*10500,r*12000,1700),FVector(7000,3000,3400));
    for(int i=-3;i<=3;i++) G->Box(FVector(i*9000,0,120),FVector(1400,800,240));
}
void ASDMapGenerator::Initialize(const FSDMapProfile& InProfile)
{
    if(!HasAuthority()) return; Profile=InProfile; Build(); ForceNetUpdate();
}
void ASDMapGenerator::OnRep_Profile(){Build();}
void ASDMapGenerator::Build()
{
    if(bBuilt || Profile.Id.IsNone()) return; bBuilt=true; const FSDMapProfile& P=Profile;
    const FString T=P.Character.ToLower();
    if(T.Contains(TEXT("airfield"))||T.Contains(TEXT("airlift"))) AirfieldBoxes(this,P,GetTypeHash(P.Id));
    else if(T.Contains(TEXT("fortress"))||T.Contains(TEXT("casemates"))) FortressBoxes(this,P,GetTypeHash(P.Id));
    else if(T.Contains(TEXT("barracks"))||T.Contains(TEXT("military compounds"))) BarracksBoxes(this,P,GetTypeHash(P.Id));
    else if(T.Contains(TEXT("park"))||T.Contains(TEXT("lake"))||T.Contains(TEXT("hill"))||T.Contains(TEXT("forest"))) BuildOpen(P,GetTypeHash(P.Id),1.f);
    else if(T.Contains(TEXT("industrial"))||T.Contains(TEXT("warehouses"))) BuildIndustrial(P,GetTypeHash(P.Id));
    else BuildUrban(P,GetTypeHash(P.Id),T.Contains(TEXT("dense"))?1.15f:0.9f);
    if(HasAuthority()) for(int32 i=0;i<P.CapturePoints.Num();++i){ASDCaptureZone* Z=GetWorld()->SpawnActor<ASDCaptureZone>(P.CapturePoints[i],FRotator::ZeroRotator); if(Z)Z->ZoneId=FName(*FString::Chr(TCHAR('A'+i)));}
}
void ASDMapGenerator::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& Out) const
{
    Super::GetLifetimeReplicatedProps(Out); DOREPLIFETIME(ASDMapGenerator,Profile);
}
