#include "SDCaptureZone.h"
#include "Components/BoxComponent.h"
#include "SDCharacter.h"
#include "SDPlayerState.h"
#include "Net/UnrealNetwork.h"
ASDCaptureZone::ASDCaptureZone(){ PrimaryActorTick.bCanEverTick=true; bReplicates=true; Volume=CreateDefaultSubobject<UBoxComponent>(TEXT("CaptureVolume")); RootComponent=Volume; Volume->SetBoxExtent(FVector(650,650,250)); }
void ASDCaptureZone::Tick(float Dt)
{
    Super::Tick(Dt); if(!HasAuthority()) return;
    TArray<AActor*> O; Volume->GetOverlappingActors(O,ASDCharacter::StaticClass()); int A=0,X=0;
    for(AActor* E:O) if(ASDCharacter* C=Cast<ASDCharacter>(E)) if(const ASDPlayerState* PS=C->GetPlayerState<ASDPlayerState>()){ if(PS->Team==ESDTeam::Allies)A++; else if(PS->Team==ESDTeam::Axis)X++; }
    if(A==X||A+X==0) return; const ESDTeam P=A>X?ESDTeam::Allies:ESDTeam::Axis; const float Dir=(Owner==P)?1.f:-1.f;
    if(Owner==ESDTeam::Spectator) { Progress += Dt*0.18f*(A>X?A:X); if(Progress>=1.f){Owner=P;Progress=1.f;} }
    else if(Owner!=P) { Progress -= Dt*0.18f*(A>X?A:X); if(Progress<=0.f){Owner=P;Progress=0.05f;} }
    else Progress=FMath::Min(1.f,Progress+Dt*0.1f);
}
void ASDCaptureZone::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& Out) const{Super::GetLifetimeReplicatedProps(Out);DOREPLIFETIME(ASDCaptureZone,Owner);DOREPLIFETIME(ASDCaptureZone,Progress);DOREPLIFETIME(ASDCaptureZone,ZoneId);}
