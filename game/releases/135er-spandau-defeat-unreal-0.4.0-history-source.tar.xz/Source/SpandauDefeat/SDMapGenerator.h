#pragma once
#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "SDTypes.h"
#include "SDMapGenerator.generated.h"
UCLASS()
class SPANDAUDEFEAT_API ASDMapGenerator : public AActor
{
    GENERATED_BODY()
public:
    ASDMapGenerator();
    void Initialize(const FSDMapProfile& InProfile);
    UPROPERTY(ReplicatedUsing=OnRep_Profile) FSDMapProfile Profile;
    virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& Out) const override;
    // Public for deterministic helper builders in this translation unit. Final authored maps replace these graybox primitives.
    void Box(const FVector& Location,const FVector& Size,const FRotator& Rotation=FRotator::ZeroRotator);
private:
    UFUNCTION() void OnRep_Profile();
    void Build();
    bool bBuilt=false;
    void BuildUrban(const FSDMapProfile&,int32 Seed,float Density);
    void BuildOpen(const FSDMapProfile&,int32 Seed,float Density);
    void BuildIndustrial(const FSDMapProfile&,int32 Seed);
};
