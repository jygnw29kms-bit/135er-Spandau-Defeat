#pragma once
#include "CoreMinimal.h"
#include "SDTypes.generated.h"

UENUM(BlueprintType)
enum class ESDTeam : uint8 { Allies=0, Axis=1, Spectator=2 };

UENUM(BlueprintType)
enum class ESDHistoricalEra : uint8
{
    Contemporary=0,
    Imperial=1,
    SecondWorldWar=2,
    Occupation1945=3,
    BerlinAirlift=4,
    ColdWar=5
};

USTRUCT(BlueprintType)
struct FSDMapProfile
{
    GENERATED_BODY()
    UPROPERTY(EditAnywhere) FName Id;
    UPROPERTY(EditAnywhere) FString DisplayName;
    UPROPERTY(EditAnywhere) FString Character;
    UPROPERTY(EditAnywhere) FVector2D ReferenceLatLon;
    UPROPERTY(EditAnywhere) float PlayAreaMeters = 1000.f;
    UPROPERTY(EditAnywhere) TArray<FVector> CapturePoints;
    UPROPERTY(EditAnywhere) TArray<FVector> AlliesSpawns;
    UPROPERTY(EditAnywhere) TArray<FVector> AxisSpawns;
    UPROPERTY(EditAnywhere) ESDHistoricalEra Era = ESDHistoricalEra::Contemporary;
    UPROPERTY(EditAnywhere) int32 HistoricalYear = 0;
    UPROPERTY(EditAnywhere) bool bHistoricallyDocumentedCombatAtSite = false;
    UPROPERTY(EditAnywhere) FString HistoryNote;
};
