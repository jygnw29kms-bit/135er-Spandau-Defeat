#pragma once
#include "CoreMinimal.h"
#include "GameFramework/Character.h"
#include "SDCharacter.generated.h"
class UCameraComponent;

UCLASS()
class SPANDAUDEFEAT_API ASDCharacter : public ACharacter
{
    GENERATED_BODY()
public:
    ASDCharacter();
    virtual void SetupPlayerInputComponent(UInputComponent* PlayerInputComponent) override;
    virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& Out) const override;
    UPROPERTY(VisibleAnywhere) UCameraComponent* Camera;
    UPROPERTY(ReplicatedUsing=OnRep_Health, BlueprintReadOnly) float Health = 100.f;
    UPROPERTY(EditDefaultsOnly) float MaxHealth = 100.f;
    UPROPERTY(EditDefaultsOnly) float WeaponDamage = 34.f;
    UPROPERTY(EditDefaultsOnly) float WeaponRange = 15000.f;
    UPROPERTY(EditDefaultsOnly) float FireInterval = 0.12f;
    UFUNCTION() void OnRep_Health();
    UFUNCTION(Server, Reliable) void ServerFire(FVector_NetQuantize Origin, FVector_NetQuantizeNormal Direction);
    void ApplyServerDamage(float Amount, AController* InstigatorController);
private:
    void MoveForward(float Value); void MoveRight(float Value); void Turn(float Value); void LookUp(float Value); void Fire();
    double LastServerShotTime = -1000.0;
};
