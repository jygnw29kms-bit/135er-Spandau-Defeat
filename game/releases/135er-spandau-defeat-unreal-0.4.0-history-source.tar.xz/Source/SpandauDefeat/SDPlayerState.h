#pragma once
#include "CoreMinimal.h"
#include "GameFramework/PlayerState.h"
#include "SDTypes.h"
#include "SDPlayerState.generated.h"
UCLASS()
class SPANDAUDEFEAT_API ASDPlayerState : public APlayerState
{
    GENERATED_BODY()
public:
    ASDPlayerState();
    UPROPERTY(Replicated, BlueprintReadOnly) ESDTeam Team = ESDTeam::Spectator;
    UPROPERTY(Replicated, BlueprintReadOnly) int32 Kills = 0;
    UPROPERTY(Replicated, BlueprintReadOnly) int32 Deaths = 0;
    virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& Out) const override;
};
