#include "SDPlayerState.h"
#include "Net/UnrealNetwork.h"
ASDPlayerState::ASDPlayerState(){ bReplicates=true; }
void ASDPlayerState::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& Out) const
{
    Super::GetLifetimeReplicatedProps(Out);
    DOREPLIFETIME(ASDPlayerState, Team); DOREPLIFETIME(ASDPlayerState, Kills); DOREPLIFETIME(ASDPlayerState, Deaths);
}
