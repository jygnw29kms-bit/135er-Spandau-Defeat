#pragma once
#include "CoreMinimal.h"
#include "GameFramework/GameMode.h"
#include "SDTypes.h"
#include "SDGameMode.generated.h"
class ASDCharacter;
UCLASS()
class SPANDAUDEFEAT_API ASDGameMode : public AGameMode
{
    GENERATED_BODY()
public:
    ASDGameMode();
    virtual void InitGame(const FString& MapName,const FString& Options,FString& ErrorMessage) override;
    virtual void BeginPlay() override;
    virtual void PostLogin(APlayerController* NewPlayer) override;
    virtual void RestartPlayer(AController* NewPlayer) override;
    void HandleDeath(ASDCharacter* Victim,AController* Killer);
    const FSDMapProfile& GetActiveProfile() const {return ActiveProfile;}
private:
    TArray<FSDMapProfile> Profiles; FSDMapProfile ActiveProfile; int32 SpawnCursorA=0,SpawnCursorX=0;
    void CreateProfiles(); ESDTeam ChooseTeam() const; FVector NextSpawn(ESDTeam Team); void Respawn(AController* Controller);
};
