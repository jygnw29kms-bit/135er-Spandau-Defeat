using UnrealBuildTool;
using System.Collections.Generic;
public class SpandauDefeatServerTarget : TargetRules
{
    public SpandauDefeatServerTarget(TargetInfo Target) : base(Target)
    {
        Type = TargetType.Server;
        DefaultBuildSettings = BuildSettingsVersion.V5;
        IncludeOrderVersion = EngineIncludeOrderVersion.Latest;
        ExtraModuleNames.Add("SpandauDefeat");
    }
}
