#!/usr/bin/env bash
set -euo pipefail
BIN=${1:-./SpandauDefeatServer}
MAP=${SPANDAU_MAP:-rathaus_spandau}
exec "$BIN" /Engine/Maps/Entry?game=/Script/SpandauDefeat.SDGameMode?MapId="$MAP" -log -port=27135 -unattended -NoSound
