#include "SDCharacter.h"
#include "Camera/CameraComponent.h"
#include "Components/CapsuleComponent.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "GameFramework/PlayerController.h"
#include "SDGameMode.h"
#include "SDPlayerState.h"
#include "Net/UnrealNetwork.h"

ASDCharacter::ASDCharacter()
{
    bReplicates = true;
    SetReplicateMovement(true);
    Camera = CreateDefaultSubobject<UCameraComponent>(TEXT("FirstPersonCamera"));
    Camera->SetupAttachment(GetCapsuleComponent());
    Camera->SetRelativeLocation(FVector(-10,0,64));
    Camera->bUsePawnControlRotation = true;
    GetCharacterMovement()->MaxWalkSpeed = 600.f;
}
void ASDCharacter::SetupPlayerInputComponent(UInputComponent* I)
{
    Super::SetupPlayerInputComponent(I);
    I->BindAxis("MoveForward",this,&ASDCharacter::MoveForward); I->BindAxis("MoveRight",this,&ASDCharacter::MoveRight);
    I->BindAxis("Turn",this,&ASDCharacter::Turn); I->BindAxis("LookUp",this,&ASDCharacter::LookUp);
    I->BindAction("Fire",IE_Pressed,this,&ASDCharacter::Fire); I->BindAction("Reload",IE_Pressed,this,&ASDCharacter::Reload); I->BindAction("Jump",IE_Pressed,this,&ACharacter::Jump);
}
void ASDCharacter::MoveForward(float V){ if(V!=0) AddMovementInput(GetActorForwardVector(),V); }
void ASDCharacter::MoveRight(float V){ if(V!=0) AddMovementInput(GetActorRightVector(),V); }
void ASDCharacter::Turn(float V){ AddControllerYawInput(V); }
void ASDCharacter::LookUp(float V){ AddControllerPitchInput(V); }
void ASDCharacter::Fire(){ if(MagazineAmmo<=0){Reload();return;} const FVector O=Camera->GetComponentLocation(); const FVector D=Camera->GetForwardVector(); ServerFire(O,D); }
void ASDCharacter::Reload(){ ServerReload(); }
void ASDCharacter::ServerFire_Implementation(FVector_NetQuantize O, FVector_NetQuantizeNormal D)
{
    const double Now=GetWorld()->GetTimeSeconds(); if(Now-LastServerShotTime < FireInterval || MagazineAmmo<=0) return; LastServerShotTime=Now; MagazineAmmo--;
    const FVector Cam=Camera->GetComponentLocation(); if(FVector::DistSquared(Cam,O)>FMath::Square(150.f)) O=Cam;
    FHitResult Hit; FCollisionQueryParams P(SCENE_QUERY_STAT(SpandauShot),true,this);
    const FVector End=O+FVector(D).GetSafeNormal()*WeaponRange;
    if(GetWorld()->LineTraceSingleByChannel(Hit,O,End,ECC_Visibility,P))
        if(ASDCharacter* Victim=Cast<ASDCharacter>(Hit.GetActor())) Victim->ApplyServerDamage(WeaponDamage,Controller);
}

void ASDCharacter::ServerReload_Implementation()
{
    if(MagazineAmmo>=MagazineSize||ReserveAmmo<=0)return;
    const int32 Need=MagazineSize-MagazineAmmo; const int32 Take=FMath::Min(Need,ReserveAmmo); MagazineAmmo+=Take; ReserveAmmo-=Take;
}

void ASDCharacter::ApplyServerDamage(float Amount,AController* InstigatorController)
{
    if(!HasAuthority()||Health<=0) return;
    const ASDPlayerState* AttackerPS=InstigatorController?InstigatorController->GetPlayerState<ASDPlayerState>():nullptr;
    const ASDPlayerState* VictimPS=GetPlayerState<ASDPlayerState>();
    if(AttackerPS&&VictimPS&&AttackerPS->Team==VictimPS->Team) return;
    Health=FMath::Max(0.f,Health-Amount);
    if(Health<=0) if(ASDGameMode* GM=GetWorld()->GetAuthGameMode<ASDGameMode>()) GM->HandleDeath(this,InstigatorController);
}
void ASDCharacter::OnRep_Health(){}
void ASDCharacter::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& Out) const{ Super::GetLifetimeReplicatedProps(Out); DOREPLIFETIME(ASDCharacter,Health); DOREPLIFETIME(ASDCharacter,MagazineAmmo); DOREPLIFETIME(ASDCharacter,ReserveAmmo); }
