#pragma once
#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "SDTypes.h"
#include "SDVisualDirector.generated.h"

UCLASS()
class SPANDAUDEFEAT_API ASDVisualDirector : public AActor
{
    GENERATED_BODY()
public:
    ASDVisualDirector();
    void ApplyMasterLook(const FSDMapProfile& Profile);
};
