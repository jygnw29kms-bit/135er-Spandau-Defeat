#pragma once
#include "CoreMinimal.h"
#include "GameFramework/Character.h"
#include "SDCharacter.generated.h"
class UCameraComponent;

UCLASS()
class SPANDAUDEFEAT_API ASDCharacter : public ACharacter
{
    GENERATED_BODY()
public:
    ASDCharacter();
    virtual void SetupPlayerInputComponent(UInputComponent* PlayerInputComponent) override;
    virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& Out) const override;
    UPROPERTY(VisibleAnywhere) UCameraComponent* Camera;
    UPROPERTY(ReplicatedUsing=OnRep_Health, BlueprintReadOnly) float Health = 100.f;
    UPROPERTY(EditDefaultsOnly) float MaxHealth = 100.f;
    UPROPERTY(EditDefaultsOnly) float WeaponDamage = 34.f;
    UPROPERTY(EditDefaultsOnly) float WeaponRange = 15000.f;
    UPROPERTY(EditDefaultsOnly) float FireInterval = 0.12f;
    UPROPERTY(Replicated, BlueprintReadOnly) int32 MagazineAmmo = 8;
    UPROPERTY(Replicated, BlueprintReadOnly) int32 ReserveAmmo = 72;
    UPROPERTY(EditDefaultsOnly) int32 MagazineSize = 8;
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly) FName WeaponLabel = TEXT("M1 GARAND");
    UFUNCTION() void OnRep_Health();
    UFUNCTION(Server, Reliable) void ServerFire(FVector_NetQuantize Origin, FVector_NetQuantizeNormal Direction);
    UFUNCTION(Server, Reliable) void ServerReload();
    void ApplyServerDamage(float Amount, AController* InstigatorController);
private:
    void MoveForward(float Value); void MoveRight(float Value); void Turn(float Value); void LookUp(float Value); void Fire(); void Reload();
    double LastServerShotTime = -1000.0;
};
