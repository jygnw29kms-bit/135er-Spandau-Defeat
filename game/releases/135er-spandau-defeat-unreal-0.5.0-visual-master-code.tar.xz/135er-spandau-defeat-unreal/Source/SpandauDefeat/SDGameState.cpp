#include "SDGameState.h"
#include "Net/UnrealNetwork.h"
ASDGameState::ASDGameState(){bReplicates=true;}
void ASDGameState::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& Out) const
{
    Super::GetLifetimeReplicatedProps(Out);
    DOREPLIFETIME(ASDGameState,AlliesTickets);
    DOREPLIFETIME(ASDGameState,AxisTickets);
    DOREPLIFETIME(ASDGameState,MatchSecondsRemaining);
}
