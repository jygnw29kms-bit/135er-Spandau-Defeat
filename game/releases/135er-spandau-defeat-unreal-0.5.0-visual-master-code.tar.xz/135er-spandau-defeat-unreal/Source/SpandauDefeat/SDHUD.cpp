#include "SDHUD.h"
#include "Engine/Canvas.h"
#include "Engine/Engine.h"
#include "EngineUtils.h"
#include "CanvasItem.h"
#include "SDGameState.h"
#include "SDCharacter.h"
#include "SDCaptureZone.h"
#include "SDPlayerState.h"

static void Rect(UCanvas* C,float X,float Y,float W,float H,const FLinearColor& Color)
{
    FCanvasTileItem I(FVector2D(X,Y),FVector2D(W,H),Color); I.BlendMode=SE_BLEND_Translucent; C->DrawItem(I);
}
static void Text(UCanvas* C,const FString& S,float X,float Y,float Scale,const FLinearColor& Color,bool Center=false)
{
    if(!GEngine||!C)return; UFont* F=GEngine->GetMediumFont();
    C->SetDrawColor(Color.ToFColor(true)); float XL=0,YL=0; C->StrLen(F,S,XL,YL); if(Center)X-=XL*Scale*.5f;
    C->DrawText(F,S,X,Y,Scale,Scale);
}
FLinearColor ASDHUD::TeamColor(bool bAllies)const{return bAllies?FLinearColor(0.08f,0.34f,0.72f,0.92f):FLinearColor(0.72f,0.08f,0.06f,0.92f);}
void ASDHUD::DrawHUD(){Super::DrawHUD();if(!Canvas)return;const float W=Canvas->SizeX,H=Canvas->SizeY;DrawTopBar(W,H);DrawObjectives(W,H);DrawMiniMap(W,H);DrawPlayerStatus(W,H);}
void ASDHUD::DrawTopBar(float W,float H)
{
    const ASDGameState* GS=GetWorld()?GetWorld()->GetGameState<ASDGameState>():nullptr; if(!GS)return;
    const float BarW=430.f,BarH=34.f,X=(W-BarW)*.5f,Y=14.f;
    Rect(Canvas,X,Y,BarW*.42f,BarH,TeamColor(true)); Rect(Canvas,X+BarW*.58f,Y,BarW*.42f,BarH,TeamColor(false)); Rect(Canvas,X+BarW*.42f,Y,BarW*.16f,BarH,FLinearColor(0.04f,0.04f,0.04f,.85f));
    Text(Canvas,FString::FromInt(GS->AlliesTickets),X+BarW*.21f,Y+4,1.0f,FLinearColor::White,true);
    Text(Canvas,FString::FromInt(GS->AxisTickets),X+BarW*.79f,Y+4,1.0f,FLinearColor::White,true);
    const int32 M=GS->MatchSecondsRemaining/60,S=GS->MatchSecondsRemaining%60; Text(Canvas,FString::Printf(TEXT("%02d:%02d"),M,S),X+BarW*.50f,Y+4,1.0f,FLinearColor::White,true);
}
void ASDHUD::DrawObjectives(float W,float H)
{
    TArray<ASDCaptureZone*> Zones; for(TActorIterator<ASDCaptureZone> It(GetWorld());It;++It)Zones.Add(*It); Zones.Sort([](const ASDCaptureZone& A,const ASDCaptureZone& B){return A.ZoneId.LexicalLess(B.ZoneId);});
    const float Start=W*.5f-(Zones.Num()-1)*34.f;
    for(int32 i=0;i<Zones.Num();++i){const ASDCaptureZone* Z=Zones[i];FLinearColor C=FLinearColor(.32f,.32f,.32f,.9f);if(Z->Owner==ESDTeam::Allies)C=TeamColor(true);else if(Z->Owner==ESDTeam::Axis)C=TeamColor(false);const float X=Start+i*68.f,Y=58.f;Rect(Canvas,X-18,Y,36,36,C);Text(Canvas,Z->ZoneId.ToString(),X,Y+5,1.f,FLinearColor::White,true);}
}
void ASDHUD::DrawMiniMap(float W,float H)
{
    const APawn* P=GetOwningPawn(); if(!P)return; const FVector PP=P->GetActorLocation(); const float S=190.f,CX=112.f,CY=H-118.f; Rect(Canvas,CX-S*.5f,CY-S*.5f,S,S,FLinearColor(0.02f,0.03f,0.04f,.72f));
    for(TActorIterator<ASDCaptureZone> It(GetWorld());It;++It){const FVector D=It->GetActorLocation()-PP; const float Scale=.0017f; const float X=FMath::Clamp(D.Y*Scale,-S*.42f,S*.42f),Y=FMath::Clamp(-D.X*Scale,-S*.42f,S*.42f);FLinearColor C=It->Owner==ESDTeam::Allies?TeamColor(true):(It->Owner==ESDTeam::Axis?TeamColor(false):FLinearColor(.7f,.7f,.7f,1));Rect(Canvas,CX+X-7,CY+Y-7,14,14,C);Text(Canvas,It->ZoneId.ToString(),CX+X,CY+Y-6,.65f,FLinearColor::White,true);}
    Text(Canvas,TEXT("N"),CX,CY-S*.5f+4,.7f,FLinearColor(.85f,.85f,.85f,1),true);
}
void ASDHUD::DrawPlayerStatus(float W,float H)
{
    const ASDCharacter* C=Cast<ASDCharacter>(GetOwningPawn()); if(!C)return; const float X=W-270.f,Y=H-104.f;Rect(Canvas,X-18,Y-15,260,92,FLinearColor(0.02f,0.02f,0.02f,.66f));
    Text(Canvas,FString::Printf(TEXT("%d | %d"),C->MagazineAmmo,C->ReserveAmmo),X,Y,1.35f,FLinearColor::White);Text(Canvas,C->WeaponLabel.ToString(),X,Y+35,.72f,FLinearColor(.9f,.9f,.9f,1));Text(Canvas,FString::Printf(TEXT("HP %.0f"),C->Health),X+155,Y+37,.72f,FLinearColor(.9f,.9f,.9f,1));
}
