#pragma once
#include "CoreMinimal.h"
#include "GameFramework/HUD.h"
#include "SDHUD.generated.h"

UCLASS()
class SPANDAUDEFEAT_API ASDHUD : public AHUD
{
    GENERATED_BODY()
public:
    virtual void DrawHUD() override;
private:
    void DrawTopBar(float W,float H);
    void DrawObjectives(float W,float H);
    void DrawPlayerStatus(float W,float H);
    void DrawMiniMap(float W,float H);
    FLinearColor TeamColor(bool bAllies) const;
};
